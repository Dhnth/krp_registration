<?php
class PendaftaranController extends Controller {
    private $pendaftaranModel;

    public function __construct() {
        $this->pendaftaranModel = $this->model('PendaftaranModel');
    }

    public function index() {
        $data = [
            'title' => 'Form Pendaftaran Komunitas Remaja Pustaka',
            'error' => ''
        ];
        $this->view('home/index', $data);
    }

    public function submit() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('');
        }

        // Validasi CSRF token (optional)
        
        // Sanitasi input
        $nama = htmlspecialchars(trim($_POST['nama_lengkap'] ?? ''));
        $kelas = htmlspecialchars(trim($_POST['kelas'] ?? ''));
        $nis = htmlspecialchars(trim($_POST['nis'] ?? ''));
        $telepon = htmlspecialchars(trim($_POST['nomor_telepon'] ?? ''));
        $alasan = htmlspecialchars(trim($_POST['alasan_masuk'] ?? ''));

        // Validasi
        $errors = [];
        
        if (empty($nama)) {
            $errors[] = 'Nama lengkap wajib diisi';
        } elseif (strlen($nama) < 3) {
            $errors[] = 'Nama lengkap minimal 3 karakter';
        }

        if (empty($kelas)) {
            $errors[] = 'Kelas wajib diisi';
        }

        if (empty($nis)) {
            $errors[] = 'NIS wajib diisi';
        } elseif (!preg_match('/^[0-9]{8,}$/', $nis)) {
            $errors[] = 'NIS harus berupa angka minimal 8 digit';
        }

        if (empty($telepon)) {
            $errors[] = 'Nomor telepon wajib diisi';
        } elseif (!preg_match('/^[0-9]{10,15}$/', $telepon)) {
            $errors[] = 'Nomor telepon harus berupa angka 10-15 digit';
        }

        if (empty($alasan)) {
            $errors[] = 'Alasan masuk wajib diisi';
        } elseif (strlen($alasan) < 10) {
            $errors[] = 'Alasan masuk minimal 10 karakter';
        }

        // Cek NIS duplikat
        if (empty($errors)) {
            $existing = $this->pendaftaranModel->getByNis($nis);
            if ($existing) {
                $errors[] = 'NIS sudah terdaftar, silakan gunakan NIS lain';
            }
        }

        if (!empty($errors)) {
            $data = [
                'title' => 'Form Pendaftaran Komunitas Remaja Pustaka',
                'errors' => $errors,
                'old' => [
                    'nama_lengkap' => $nama,
                    'kelas' => $kelas,
                    'nis' => $nis,
                    'nomor_telepon' => $telepon,
                    'alasan_masuk' => $alasan
                ]
            ];
            $this->view('home/index', $data);
            return;
        }

        // Simpan data
        $data = [
            'nama_lengkap' => $nama,
            'kelas' => $kelas,
            'nis' => $nis,
            'nomor_telepon' => $telepon,
            'alasan_masuk' => $alasan
        ];

        if ($this->pendaftaranModel->create($data)) {
            $this->view('home/success', [
                'title' => 'Pendaftaran Berhasil',
                'nama' => $nama
            ]);
        } else {
            $data = [
                'title' => 'Form Pendaftaran Komunitas Remaja Pustaka',
                'error' => 'Terjadi kesalahan saat menyimpan data. Silakan coba lagi.',
                'old' => [
                    'nama_lengkap' => $nama,
                    'kelas' => $kelas,
                    'nis' => $nis,
                    'nomor_telepon' => $telepon,
                    'alasan_masuk' => $alasan
                ]
            ];
            $this->view('home/index', $data);
        }
    }
}