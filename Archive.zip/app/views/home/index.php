<?php $this->view('partials/head', ['title' => $title ?? 'Pendaftaran Anggota Baru']) ?>

<body class="min-h-screen flex flex-col bg-[<?= THEME_SURFACE ?>] font-['Inter']">
    <?php $this->view('partials/header') ?>

    <main class="flex-grow container mx-auto px-4 max-w-[1200px] py-8 md:py-12">
        <div class="max-w-2xl mx-auto">
            <!-- Header -->
            <div class="text-center mb-8 md:mb-12">
                <div class="inline-flex items-center gap-2 bg-[<?= THEME_PRIMARY_CONTAINER ?>] text-white px-4 py-1.5 rounded-full text-sm font-semibold mb-4">
                    <span class="material-symbols-outlined text-[18px]">groups</span>
                    <span>Komunitas Remaja Pustaka</span>
                </div>
                <h1 class="font-['Plus_Jakarta_Sans'] text-3xl md:text-4xl font-bold text-[<?= THEME_ON_SURFACE ?>] mb-3">
                    Pendaftaran Anggota Baru
                </h1>
                <p class="text-base md:text-lg text-[<?= THEME_ON_SURFACE_VARIANT ?>] max-w-lg mx-auto">
                    Bergabunglah dan jadilah bagian dari komunitas literasi yang inspiratif
                </p>
            </div>

            <!-- Form -->
            <div class="bg-white rounded-xl md:rounded-2xl border border-[<?= THEME_OUTLINE_VARIANT ?>] p-6 md:p-8 shadow-sm">
                <?php if (!empty($errors)): ?>
                    <div class="mb-6 bg-red-50 border border-[<?= THEME_ERROR ?>] text-[<?= THEME_ERROR ?>] rounded-lg p-4">
                        <div class="flex items-start gap-3">
                            <span class="material-symbols-outlined text-[<?= THEME_ERROR ?>]">error</span>
                            <div>
                                <p class="font-semibold text-sm">Mohon perbaiki kesalahan berikut:</p>
                                <ul class="list-disc list-inside text-sm mt-1">
                                    <?php foreach ($errors as $error): ?>
                                        <li><?= htmlspecialchars($error) ?></li>
                                    <?php endforeach ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                <?php endif ?>

                <?php if (!empty($error)): ?>
                    <div class="mb-6 bg-red-50 border border-[<?= THEME_ERROR ?>] text-[<?= THEME_ERROR ?>] rounded-lg p-4">
                        <div class="flex items-center gap-3">
                            <span class="material-symbols-outlined text-[<?= THEME_ERROR ?>]">error</span>
                            <p class="text-sm"><?= htmlspecialchars($error) ?></p>
                        </div>
                    </div>
                <?php endif ?>

                <form id="registrationForm" action="<?= BASE_URL ?>/pendaftaran/submit" method="POST" class="space-y-6" novalidate>
                    <!-- Nama Lengkap -->
                    <div>
                        <label for="nama_lengkap" class="block text-sm font-semibold text-[<?= THEME_ON_SURFACE ?>] mb-1.5">
                            Nama Lengkap
                        </label>
                        <div class="relative">
                            <input 
                                type="text" 
                                id="nama_lengkap" 
                                name="nama_lengkap" 
                                value="<?= htmlspecialchars($old['nama_lengkap'] ?? '') ?>"
                                class="w-full h-11 px-4 pr-11 border border-[<?= THEME_OUTLINE_VARIANT ?>] rounded-lg focus:outline-none focus:ring-2 focus:ring-[<?= THEME_PRIMARY_CONTAINER ?>] focus:border-transparent transition-all text-sm bg-[<?= THEME_SURFACE_CONTAINER_LOW ?>]"
                                placeholder="Masukkan nama lengkap Anda"
                                minlength="3"
                                maxlength="100"
                                required
                                autofocus
                            >
                            <span class="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-[<?= THEME_OUTLINE ?>] text-[20px]">person</span>
                        </div>
                        <div class="mt-1 text-xs text-[<?= THEME_ON_SURFACE_VARIANT ?>] flex justify-between">
                            <span id="nama_lengkap_error" class="text-[<?= THEME_ERROR ?>] hidden"></span>
                            <span id="nama_lengkap_counter" class="text-[<?= THEME_ON_SURFACE_VARIANT ?>]">0/100</span>
                        </div>
                    </div>

                    <!-- Kelas & NIS Grid -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                        <!-- Kelas -->
                        <div>
                            <label for="kelas" class="block text-sm font-semibold text-[<?= THEME_ON_SURFACE ?>] mb-1.5">
                                Kelas
                            </label>
                            <input 
                                type="text" 
                                id="kelas" 
                                name="kelas" 
                                value="<?= htmlspecialchars($old['kelas'] ?? '') ?>"
                                class="w-full h-11 px-4 border border-[<?= THEME_OUTLINE_VARIANT ?>] rounded-lg focus:outline-none focus:ring-2 focus:ring-[<?= THEME_PRIMARY_CONTAINER ?>] focus:border-transparent transition-all text-sm bg-[<?= THEME_SURFACE_CONTAINER_LOW ?>]"
                                placeholder="Contoh: XI IPA 1"
                                minlength="2"
                                maxlength="20"
                                required
                            >
                            <div class="mt-1 text-xs text-[<?= THEME_ON_SURFACE_VARIANT ?>] flex justify-between">
                                <span id="kelas_error" class="text-[<?= THEME_ERROR ?>] hidden"></span>
                                <span id="kelas_counter" class="text-[<?= THEME_ON_SURFACE_VARIANT ?>]">0/20</span>
                            </div>
                        </div>

                        <!-- NIS -->
                        <div>
                            <label for="nis" class="block text-sm font-semibold text-[<?= THEME_ON_SURFACE ?>] mb-1.5">
                                NIS (Nomor Induk Siswa)
                            </label>
                            <input 
                                type="text" 
                                id="nis" 
                                name="nis" 
                                value="<?= htmlspecialchars($old['nis'] ?? '') ?>"
                                class="w-full h-11 px-4 border border-[<?= THEME_OUTLINE_VARIANT ?>] rounded-lg focus:outline-none focus:ring-2 focus:ring-[<?= THEME_PRIMARY_CONTAINER ?>] focus:border-transparent transition-all text-sm bg-[<?= THEME_SURFACE_CONTAINER_LOW ?>]"
                                placeholder="8 digit angka"
                                maxlength="20"
                                required
                                inputmode="numeric"
                            >
                            <div class="mt-1 text-xs text-[<?= THEME_ON_SURFACE_VARIANT ?>] flex justify-between">
                                <span id="nis_error" class="text-[<?= THEME_ERROR ?>] hidden"></span>
                                <span id="nis_counter" class="text-[<?= THEME_ON_SURFACE_VARIANT ?>]">0/20</span>
                            </div>
                        </div>
                    </div>

                    <!-- Nomor Telepon -->
                    <div>
                        <label for="nomor_telepon" class="block text-sm font-semibold text-[<?= THEME_ON_SURFACE ?>] mb-1.5">
                            Nomor Telepon / WhatsApp
                        </label>
                        <div class="relative">
                            <input 
                                type="tel" 
                                id="nomor_telepon" 
                                name="nomor_telepon" 
                                value="<?= htmlspecialchars($old['nomor_telepon'] ?? '') ?>"
                                class="w-full h-11 px-4 pr-11 border border-[<?= THEME_OUTLINE_VARIANT ?>] rounded-lg focus:outline-none focus:ring-2 focus:ring-[<?= THEME_PRIMARY_CONTAINER ?>] focus:border-transparent transition-all text-sm bg-[<?= THEME_SURFACE_CONTAINER_LOW ?>]"
                                placeholder="Contoh: 081234567890"
                                maxlength="15"
                                required
                                inputmode="numeric"
                            >
                            <span class="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-[<?= THEME_OUTLINE ?>] text-[20px]">call</span>
                        </div>
                        <div class="mt-1 text-xs text-[<?= THEME_ON_SURFACE_VARIANT ?>] flex justify-between">
                            <span id="nomor_telepon_error" class="text-[<?= THEME_ERROR ?>] hidden"></span>
                            <span id="nomor_telepon_counter" class="text-[<?= THEME_ON_SURFACE_VARIANT ?>]">0/15</span>
                        </div>
                    </div>

                    <!-- Alasan Masuk -->
                    <div>
                        <label for="alasan_masuk" class="block text-sm font-semibold text-[<?= THEME_ON_SURFACE ?>] mb-1.5">
                            Alasan Masuk
                        </label>
                        <textarea 
                            id="alasan_masuk" 
                            name="alasan_masuk" 
                            rows="4" 
                            class="w-full px-4 py-3 border border-[<?= THEME_OUTLINE_VARIANT ?>] rounded-lg focus:outline-none focus:ring-2 focus:ring-[<?= THEME_PRIMARY_CONTAINER ?>] focus:border-transparent transition-all text-sm bg-[<?= THEME_SURFACE_CONTAINER_LOW ?>] resize-y"
                            placeholder="Ceritakan alasan Anda ingin bergabung dengan komunitas ini..."
                            minlength="10"
                            maxlength="500"
                            required
                        ><?= htmlspecialchars($old['alasan_masuk'] ?? '') ?></textarea>
                        <div class="mt-1 text-xs text-[<?= THEME_ON_SURFACE_VARIANT ?>] flex justify-between">
                            <span id="alasan_masuk_error" class="text-[<?= THEME_ERROR ?>] hidden"></span>
                            <span id="alasan_masuk_counter" class="text-[<?= THEME_ON_SURFACE_VARIANT ?>]">0/500</span>
                        </div>
                    </div>

                    <!-- Terms -->
                    <div class="flex items-start gap-3 pt-2">
                        <input 
                            type="checkbox" 
                            id="terms" 
                            name="terms" 
                            class="mt-0.5 w-4 h-4 rounded border-[<?= THEME_OUTLINE_VARIANT ?>] text-[<?= THEME_PRIMARY_CONTAINER ?>] focus:ring-[<?= THEME_PRIMARY_CONTAINER ?>] focus:ring-2"
                            required
                        >
                        <label for="terms" class="text-sm text-[<?= THEME_ON_SURFACE_VARIANT ?>]">
                            Saya setuju dengan ketentuan keanggotaan dan bersedia berkontribusi aktif dalam komunitas.
                        </label>
                    </div>
                    <div id="terms_error" class="text-xs text-[<?= THEME_ERROR ?>] hidden">Anda harus menyetujui ketentuan</div>

                    <!-- Submit -->
                    <button 
                        type="submit" 
                        class="w-full h-11 bg-[<?= THEME_PRIMARY_CONTAINER ?>] hover:bg-[<?= THEME_PRIMARY ?>] text-white font-semibold rounded-lg transition-all duration-200 hover:shadow-lg active:scale-[0.98] text-sm flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                        id="submitBtn"
                    >
                        <span>Kirim Pendaftaran</span>
                        <span class="material-symbols-outlined text-[18px]">send</span>
                    </button>
                </form>
            </div>
        </div>
    </main>

    <?php $this->view('partials/footer') ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('registrationForm');
            const submitBtn = document.getElementById('submitBtn');

            // Update counter function
            function updateCounter(inputId, counterId, maxLength) {
                const input = document.getElementById(inputId);
                const counter = document.getElementById(counterId);
                
                if (input && counter) {
                    input.addEventListener('input', function() {
                        const len = this.value.length;
                        counter.textContent = len + '/' + maxLength;
                        
                        // Warna merah jika melewati batas
                        if (len > maxLength) {
                            counter.style.color = '#ba1a1a';
                        } else {
                            counter.style.color = '#3d4a3d';
                        }
                    });
                }
            }

            // Update semua counter
            updateCounter('nama_lengkap', 'nama_lengkap_counter', 100);
            updateCounter('kelas', 'kelas_counter', 20);
            updateCounter('nis', 'nis_counter', 20);
            updateCounter('nomor_telepon', 'nomor_telepon_counter', 15);
            updateCounter('alasan_masuk', 'alasan_masuk_counter', 500);

            // Fungsi validasi per field
            function validateField(inputId, errorId, validator, errorMessage) {
                const input = document.getElementById(inputId);
                const errorEl = document.getElementById(errorId);
                
                if (input && errorEl) {
                    input.addEventListener('input', function() {
                        const value = this.value;
                        
                        if (value.length > 0) {
                            if (!validator(value)) {
                                this.classList.add('border-[#ba1a1a]');
                                this.classList.remove('border-[<?= THEME_OUTLINE_VARIANT ?>]');
                                errorEl.textContent = errorMessage;
                                errorEl.classList.remove('hidden');
                            } else {
                                this.classList.remove('border-[#ba1a1a]');
                                this.classList.add('border-[<?= THEME_OUTLINE_VARIANT ?>]');
                                errorEl.classList.add('hidden');
                            }
                        } else {
                            this.classList.remove('border-[#ba1a1a]');
                            this.classList.add('border-[<?= THEME_OUTLINE_VARIANT ?>]');
                            errorEl.classList.add('hidden');
                        }
                    });
                }
            }

            // Validasi Nama Lengkap
            validateField('nama_lengkap', 'nama_lengkap_error', 
                (val) => val.trim().length >= 3 && val.trim().length <= 100,
                'Nama lengkap minimal 3 karakter'
            );

            // Validasi Kelas
            validateField('kelas', 'kelas_error',
                (val) => val.trim().length >= 2 && val.trim().length <= 20,
                'Kelas minimal 2 karakter'
            );

            // Validasi NIS (hanya angka, min 8 digit)
            validateField('nis', 'nis_error',
                (val) => {
                    const cleaned = val.replace(/\D/g, '');
                    return cleaned.length >= 8 && cleaned.length <= 20;
                },
                'NIS harus 8-20 digit angka'
            );

            // Validasi Nomor Telepon (hanya angka, min 10 digit)
            validateField('nomor_telepon', 'nomor_telepon_error',
                (val) => {
                    const cleaned = val.replace(/\D/g, '');
                    return cleaned.length >= 10 && cleaned.length <= 15;
                },
                'Nomor telepon harus 10-15 digit angka'
            );

            // Validasi Alasan Masuk
            validateField('alasan_masuk', 'alasan_masuk_error',
                (val) => val.trim().length >= 10 && val.trim().length <= 500,
                'Alasan minimal 10 karakter'
            );

            // Hanya angka untuk NIS dan Telepon
            ['nis', 'nomor_telepon'].forEach(function(fieldId) {
                const input = document.getElementById(fieldId);
                if (input) {
                    input.addEventListener('keypress', function(e) {
                        const char = String.fromCharCode(e.which);
                        if (!/[0-9]/.test(char)) {
                            e.preventDefault();
                        }
                    });

                    input.addEventListener('paste', function(e) {
                        const paste = (e.clipboardData || window.clipboardData).getData('text');
                        if (!/^[0-9]+$/.test(paste)) {
                            e.preventDefault();
                        }
                    });
                }
            });

            // Terms validation
            const termsCheckbox = document.getElementById('terms');
            const termsError = document.getElementById('terms_error');

            if (termsCheckbox) {
                termsCheckbox.addEventListener('change', function() {
                    if (this.checked) {
                        termsError.classList.add('hidden');
                        this.classList.remove('border-[#ba1a1a]');
                    } else {
                        termsError.classList.remove('hidden');
                        this.classList.add('border-[#ba1a1a]');
                    }
                });
            }

            // Form submit validation
            form.addEventListener('submit', function(e) {
                let isValid = true;

                // Validasi semua field
                const fields = {
                    nama_lengkap: {
                        validator: (val) => val.trim().length >= 3 && val.trim().length <= 100,
                        error: 'Nama lengkap minimal 3 karakter'
                    },
                    kelas: {
                        validator: (val) => val.trim().length >= 2 && val.trim().length <= 20,
                        error: 'Kelas minimal 2 karakter'
                    },
                    nis: {
                        validator: (val) => {
                            const cleaned = val.replace(/\D/g, '');
                            return cleaned.length >= 8 && cleaned.length <= 20;
                        },
                        error: 'NIS harus 8-20 digit angka'
                    },
                    nomor_telepon: {
                        validator: (val) => {
                            const cleaned = val.replace(/\D/g, '');
                            return cleaned.length >= 10 && cleaned.length <= 15;
                        },
                        error: 'Nomor telepon harus 10-15 digit angka'
                    },
                    alasan_masuk: {
                        validator: (val) => val.trim().length >= 10 && val.trim().length <= 500,
                        error: 'Alasan minimal 10 karakter'
                    }
                };

                Object.keys(fields).forEach(function(fieldId) {
                    const input = document.getElementById(fieldId);
                    const errorEl = document.getElementById(fieldId + '_error');
                    const isValidField = fields[fieldId].validator(input.value);

                    if (!isValidField && input.value.length > 0) {
                        isValid = false;
                        input.classList.add('border-[#ba1a1a]');
                        if (errorEl) {
                            errorEl.textContent = fields[fieldId].error;
                            errorEl.classList.remove('hidden');
                        }
                    } else if (input.value.length === 0) {
                        isValid = false;
                        input.classList.add('border-[#ba1a1a]');
                        if (errorEl) {
                            errorEl.textContent = 'Field ini wajib diisi';
                            errorEl.classList.remove('hidden');
                        }
                    }
                });

                // Validasi terms
                if (!termsCheckbox.checked) {
                    isValid = false;
                    termsError.classList.remove('hidden');
                    termsCheckbox.classList.add('border-[#ba1a1a]');
                }

                if (!isValid) {
                    e.preventDefault();
                    const firstError = document.querySelector('.border-[#ba1a1a]');
                    if (firstError) {
                        firstError.focus();
                        firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }
                    return;
                }

                // Loading state
                submitBtn.disabled = true;
                submitBtn.innerHTML = `
                    <span class="flex items-center gap-2">
                        <svg class="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Memproses...
                    </span>
                `;
            });

            // Reset error on focus
            document.querySelectorAll('input, textarea').forEach(function(el) {
                el.addEventListener('focus', function() {
                    this.classList.remove('border-[#ba1a1a]');
                    this.classList.add('border-[<?= THEME_OUTLINE_VARIANT ?>]');
                    const errorEl = document.getElementById(this.id + '_error');
                    if (errorEl) {
                        errorEl.classList.add('hidden');
                    }
                });
            });
        });
    </script>
</body>
</html>