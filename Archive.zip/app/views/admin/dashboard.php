<?php $this->view('partials/head', ['title' => $title ?? 'Dashboard Admin']) ?>

<body class="min-h-screen flex flex-col bg-[<?= THEME_SURFACE ?>] font-['Inter']">
    <!-- Admin Header -->
    <header class="bg-[<?= THEME_SURFACE_CONTAINER_LOW ?>] border-b border-[<?= THEME_OUTLINE_VARIANT ?>] py-3 md:py-4 fixed top-0 left-0 right-0 z-50">
        <div class="container mx-auto px-4 max-w-[1200px]">
            <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div class="flex items-center gap-2 md:gap-3">
                    <div class="w-8 h-8 md:w-10 md:h-10 bg-[<?= THEME_PRIMARY_CONTAINER ?>] rounded-lg flex items-center justify-center">
                        <span class="material-symbols-outlined text-white text-sm md:text-base">admin_panel_settings</span>
                    </div>
                    <div>
                        <h1 class="font-['Plus_Jakarta_Sans'] text-base md:text-xl font-bold text-[<?= THEME_ON_SURFACE ?>] leading-tight">
                            Dashboard Admin
                        </h1>
                        <p class="text-[10px] md:text-xs text-[<?= THEME_ON_SURFACE_VARIANT ?>]">
                            <span class="material-symbols-outlined text-[12px] align-middle">groups</span>
                            Total Pendaftar: <?= $total ?? 0 ?>
                        </p>
                    </div>
                </div>
                
                <div class="flex items-center gap-2 w-full sm:w-auto">
                    <a href="<?= BASE_URL ?>" class="text-[<?= THEME_ON_SURFACE_VARIANT ?>] hover:text-[<?= THEME_PRIMARY ?>] transition-colors text-sm font-medium px-3 py-1.5 border border-[<?= THEME_OUTLINE_VARIANT ?>] rounded-lg hover:border-[<?= THEME_PRIMARY_CONTAINER ?>] flex items-center gap-1.5">
                        <span class="material-symbols-outlined text-[18px]">home</span>
                        <span class="hidden xs:inline">Beranda</span>
                    </a>
                    <a href="<?= BASE_URL ?>/admin/logout" class="text-red-600 hover:text-red-700 transition-colors text-sm font-medium px-3 py-1.5 border border-red-200 rounded-lg hover:border-red-300 flex items-center gap-1.5">
                        <span class="material-symbols-outlined text-[18px]">logout</span>
                        <span class="hidden xs:inline">Keluar</span>
                    </a>
                </div>
            </div>
        </div>
    </header>

    <main class="flex-grow container mx-auto px-4 max-w-[1200px] pt-20 pb-8 md:pt-24 md:pb-12">
        <!-- Alert Messages -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="mb-4 bg-green-50 border border-green-500 text-green-700 rounded-lg p-3 md:p-4 flex items-center gap-2">
                <span class="material-symbols-outlined text-green-500">check_circle</span>
                <p class="text-sm md:text-base"><?= $_SESSION['success'] ?></p>
                <?php unset($_SESSION['success']) ?>
            </div>
        <?php endif ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="mb-4 bg-red-50 border border-[<?= THEME_ERROR ?>] text-[<?= THEME_ERROR ?>] rounded-lg p-3 md:p-4 flex items-center gap-2">
                <span class="material-symbols-outlined text-[<?= THEME_ERROR ?>]">error</span>
                <p class="text-sm md:text-base"><?= $_SESSION['error'] ?></p>
                <?php unset($_SESSION['error']) ?>
            </div>
        <?php endif ?>

        <!-- Statistics Cards -->
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 md:gap-4 mb-6 md:mb-8">
            <div class="bg-white rounded-xl border border-[<?= THEME_OUTLINE_VARIANT ?>] p-3 md:p-4 shadow-sm">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-xs text-[<?= THEME_ON_SURFACE_VARIANT ?>]">Total</p>
                        <p class="text-xl md:text-2xl font-bold text-[<?= THEME_ON_SURFACE ?>] font-['Plus_Jakarta_Sans']"><?= $total ?? 0 ?></p>
                    </div>
                    <div class="w-8 h-8 md:w-10 md:h-10 bg-[<?= THEME_SURFACE_CONTAINER_HIGH ?>] rounded-lg flex items-center justify-center">
                        <span class="material-symbols-outlined text-[<?= THEME_PRIMARY_CONTAINER ?>]">groups</span>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-xl border border-[<?= THEME_OUTLINE_VARIANT ?>] p-3 md:p-4 shadow-sm">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-xs text-[<?= THEME_ON_SURFACE_VARIANT ?>]">Hari Ini</p>
                        <p class="text-xl md:text-2xl font-bold text-[<?= THEME_ON_SURFACE ?>] font-['Plus_Jakarta_Sans']"><?= $today ?? 0 ?></p>
                    </div>
                    <div class="w-8 h-8 md:w-10 md:h-10 bg-green-100 rounded-lg flex items-center justify-center">
                        <span class="material-symbols-outlined text-[<?= THEME_PRIMARY_CONTAINER ?>]">today</span>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-xl border border-[<?= THEME_OUTLINE_VARIANT ?>] p-3 md:p-4 shadow-sm">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-xs text-[<?= THEME_ON_SURFACE_VARIANT ?>]">Bulan Ini</p>
                        <p class="text-xl md:text-2xl font-bold text-[<?= THEME_ON_SURFACE ?>] font-['Plus_Jakarta_Sans']"><?= $month ?? 0 ?></p>
                    </div>
                    <div class="w-8 h-8 md:w-10 md:h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <span class="material-symbols-outlined text-[<?= THEME_PRIMARY_CONTAINER ?>]">calendar_month</span>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-xl border border-[<?= THEME_OUTLINE_VARIANT ?>] p-3 md:p-4 shadow-sm">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-xs text-[<?= THEME_ON_SURFACE_VARIANT ?>]">Terakhir</p>
                        <p class="text-sm md:text-base font-semibold text-[<?= THEME_ON_SURFACE ?>] truncate max-w-[80px]">
                            <?php 
                                if (!empty($pendaftaran) && is_array($pendaftaran) && count($pendaftaran) > 0) {
                                    echo htmlspecialchars($pendaftaran[0]['nama_lengkap'] ?? '-');
                                } else {
                                    echo '-';
                                }
                            ?>
                        </p>
                    </div>
                    <div class="w-8 h-8 md:w-10 md:h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                        <span class="material-symbols-outlined text-[<?= THEME_PRIMARY_CONTAINER ?>]">person_add</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Table -->
        <div class="bg-white rounded-xl border border-[<?= THEME_OUTLINE_VARIANT ?>] shadow-sm overflow-hidden">
            <!-- Table Header -->
            <div class="p-3 md:p-4 border-b border-[<?= THEME_OUTLINE_VARIANT ?>] bg-[<?= THEME_SURFACE_CONTAINER_LOW ?>]">
                <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                    <h2 class="font-['Plus_Jakarta_Sans'] text-base md:text-lg font-semibold text-[<?= THEME_ON_SURFACE ?>] flex items-center gap-2">
                        <span class="material-symbols-outlined text-[<?= THEME_PRIMARY_CONTAINER ?>]">list</span>
                        Daftar Pendaftar
                    </h2>
                    <div class="flex items-center gap-2 w-full sm:w-auto">
                        <div class="relative flex-1 sm:flex-none">
                            <input 
                                type="text" 
                                id="searchInput"
                                placeholder="Cari nama, kelas, NIS..." 
                                class="w-full sm:w-48 h-9 px-3 pr-9 text-sm border border-[<?= THEME_OUTLINE_VARIANT ?>] rounded-lg focus:outline-none focus:ring-2 focus:ring-[<?= THEME_PRIMARY_CONTAINER ?>] focus:border-transparent bg-[<?= THEME_SURFACE_CONTAINER_LOW ?>]"
                            >
                            <span class="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-[<?= THEME_ON_SURFACE_VARIANT ?>] text-[18px]">search</span>
                        </div>
                        
                        <!-- Tombol Export -->
                        <div class="flex items-center gap-1.5">
                            <a href="<?= BASE_URL ?>/admin/export" class="p-1.5 text-[<?= THEME_ON_SURFACE_VARIANT ?>] hover:text-[<?= THEME_PRIMARY_CONTAINER ?>] transition-colors border border-[<?= THEME_OUTLINE_VARIANT ?>] rounded-lg hover:border-[<?= THEME_PRIMARY_CONTAINER ?>] flex items-center gap-1" title="Export CSV">
                                <span class="material-symbols-outlined text-[18px]">file_download</span>
                            </a>
                            <a href="<?= BASE_URL ?>/admin/exportExcel" class="p-1.5 text-[<?= THEME_ON_SURFACE_VARIANT ?>] hover:text-[<?= THEME_PRIMARY_CONTAINER ?>] transition-colors border border-[<?= THEME_OUTLINE_VARIANT ?>] rounded-lg hover:border-[<?= THEME_PRIMARY_CONTAINER ?>] flex items-center gap-1" title="Export Excel (XLSX)">
                                <span class="material-symbols-outlined text-[18px]">table_chart</span>
                            </a>
                            <button onclick="window.location.reload()" class="p-1.5 text-[<?= THEME_ON_SURFACE_VARIANT ?>] hover:text-[<?= THEME_PRIMARY ?>] transition-colors border border-[<?= THEME_OUTLINE_VARIANT ?>] rounded-lg hover:border-[<?= THEME_PRIMARY_CONTAINER ?>]">
                                <span class="material-symbols-outlined text-[18px]">refresh</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Table Body -->
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-[<?= THEME_SURFACE_CONTAINER_LOW ?>]">
                        <tr>
                            <th class="px-3 md:px-4 py-2 md:py-3 text-left text-xs font-semibold text-[<?= THEME_ON_SURFACE_VARIANT ?>] uppercase tracking-wider">#</th>
                            <th class="px-3 md:px-4 py-2 md:py-3 text-left text-xs font-semibold text-[<?= THEME_ON_SURFACE_VARIANT ?>] uppercase tracking-wider">Nama</th>
                            <th class="px-3 md:px-4 py-2 md:py-3 text-left text-xs font-semibold text-[<?= THEME_ON_SURFACE_VARIANT ?>] uppercase tracking-wider hidden sm:table-cell">Kelas</th>
                            <th class="px-3 md:px-4 py-2 md:py-3 text-left text-xs font-semibold text-[<?= THEME_ON_SURFACE_VARIANT ?>] uppercase tracking-wider hidden md:table-cell">NIS</th>
                            <th class="px-3 md:px-4 py-2 md:py-3 text-left text-xs font-semibold text-[<?= THEME_ON_SURFACE_VARIANT ?>] uppercase tracking-wider hidden lg:table-cell">Telepon</th>
                            <th class="px-3 md:px-4 py-2 md:py-3 text-left text-xs font-semibold text-[<?= THEME_ON_SURFACE_VARIANT ?>] uppercase tracking-wider hidden xl:table-cell">Alasan</th>
                            <th class="px-3 md:px-4 py-2 md:py-3 text-left text-xs font-semibold text-[<?= THEME_ON_SURFACE_VARIANT ?>] uppercase tracking-wider">Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="tableBody">
                        <?php if (empty($pendaftaran) || !is_array($pendaftaran) || count($pendaftaran) === 0): ?>
                            <tr>
                                <td colspan="7" class="px-3 md:px-4 py-8 md:py-12 text-center text-[<?= THEME_ON_SURFACE_VARIANT ?>]">
                                    <span class="material-symbols-outlined text-3xl md:text-4xl block mb-2 text-[<?= THEME_OUTLINE_VARIANT ?>]">inbox</span>
                                    <p class="text-sm">Belum ada data pendaftaran</p>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($pendaftaran as $index => $item): ?>
                                <tr class="border-b border-[<?= THEME_OUTLINE_VARIANT ?>] hover:bg-[<?= THEME_SURFACE_CONTAINER_LOW ?>] transition-colors">
                                    <td class="px-3 md:px-4 py-2 md:py-3 text-sm text-[<?= THEME_ON_SURFACE_VARIANT ?>]">
                                        <?= $index + 1 ?>
                                    </td>
                                    <td class="px-3 md:px-4 py-2 md:py-3 text-sm font-medium text-[<?= THEME_ON_SURFACE ?>]">
                                        <?= htmlspecialchars($item['nama_lengkap'] ?? '') ?>
                                        <span class="block sm:hidden text-xs text-[<?= THEME_ON_SURFACE_VARIANT ?>] font-normal">
                                            <?= htmlspecialchars($item['kelas'] ?? '') ?>
                                        </span>
                                    </td>
                                    <td class="px-3 md:px-4 py-2 md:py-3 text-sm text-[<?= THEME_ON_SURFACE_VARIANT ?>] hidden sm:table-cell">
                                        <?= htmlspecialchars($item['kelas'] ?? '') ?>
                                    </td>
                                    <td class="px-3 md:px-4 py-2 md:py-3 text-sm text-[<?= THEME_ON_SURFACE_VARIANT ?>] hidden md:table-cell">
                                        <?= htmlspecialchars($item['nis'] ?? '') ?>
                                    </td>
                                    <td class="px-3 md:px-4 py-2 md:py-3 text-sm text-[<?= THEME_ON_SURFACE_VARIANT ?>] hidden lg:table-cell">
                                        <?= htmlspecialchars($item['nomor_telepon'] ?? '') ?>
                                    </td>
                                    <td class="px-3 md:px-4 py-2 md:py-3 text-sm text-[<?= THEME_ON_SURFACE_VARIANT ?>] hidden xl:table-cell max-w-[150px] truncate">
                                        <?= htmlspecialchars($item['alasan_masuk'] ?? '') ?>
                                    </td>
                                    <td class="px-3 md:px-4 py-2 md:py-3">
                                        <form action="<?= BASE_URL ?>/admin/delete" method="POST" onsubmit="return confirm('Yakin ingin menghapus data ini?')" class="inline">
                                            <input type="hidden" name="id" value="<?= $item['id'] ?? '' ?>">
                                            <button type="submit" class="text-red-600 hover:text-red-700 transition-colors p-1 hover:bg-red-50 rounded-lg flex items-center gap-1">
                                                <span class="material-symbols-outlined text-[20px]">delete</span>
                                                <span class="sr-only">Hapus</span>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach ?>
                        <?php endif ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Table Footer -->
            <div class="px-3 md:px-4 py-2 md:py-3 border-t border-[<?= THEME_OUTLINE_VARIANT ?>] bg-[<?= THEME_SURFACE_CONTAINER_LOW ?>] text-xs text-[<?= THEME_ON_SURFACE_VARIANT ?>] flex justify-between items-center">
                <span class="flex items-center gap-1.5">
                    <span class="material-symbols-outlined text-[14px]">database</span>
                    Total: <?= isset($pendaftaran) && is_array($pendaftaran) ? count($pendaftaran) : 0 ?> data
                </span>
                <span class="flex items-center gap-1.5">
                    <span class="material-symbols-outlined text-[14px]">schedule</span>
                    <?= date('d/m/Y H:i') ?>
                </span>
            </div>
        </div>
    </main>

    <script>
        // Search functionality
        document.getElementById('searchInput').addEventListener('keyup', function() {
            const searchText = this.value.toLowerCase();
            const rows = document.querySelectorAll('#tableBody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchText) ? '' : 'none';
            });
        });
    </script>

    <?php $this->view('partials/footer') ?>
</body>
</html>